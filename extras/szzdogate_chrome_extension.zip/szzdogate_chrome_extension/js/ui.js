$(document).ready(function () {
    var slide = false;

        $('li.parent').hover(function () {
        if ($(this).find('> ul').css('display') == "none") {
            $(this).find('> ul').show();
            slide = true;
        }
    }, function () {
        if (slide == true) {
            $(this).find('> ul').hide();
            slide = false;
        }
    });

    $('nav strong').click(function (event) {
        $('body').addClass('nav-open');
        $('#nav_container').height($(window).height());
        $('.nav-open').height($(window).height());
        $('nav ul').animate({width: 'toggle'}, 'fast');
        event.stopPropagation();
    });

    $('body').click(function () {
        if ($("body").hasClass("nav-open")) {
            $('nav ul').animate({width: 'toggle'}, 'fast');
            $('body').removeClass('nav-open');
        }
    });

    $("#nav_container").click( function(e) {
        e.stopPropagation(); // this stops the event from bubbling up to the body
    });

    $(window).resize(function(){     
      if ($('header').width() >= 650 ){
        $("#nav_container").css({ 'display' : '' });
        $("nav ul").css({ 'display' : '' });
        $('body').removeClass('nav-open');
      }
    });
});