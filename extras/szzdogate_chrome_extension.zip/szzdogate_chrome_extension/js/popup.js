let changeColor = document.getElementById('changeColor');

chrome.storage.sync.get('color', function (data) {
  changeColor.style.backgroundColor = data.color;
  changeColor.setAttribute('value', data.color);
});

changeColor.onclick = function (element) {
  let color = element.target.value;
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.executeScript(
      tabs[0].id,
      { code: 'document.body.style.backgroundColor = "' + color + '";' });
  });

  //region {variables and functions}
  var greeting = "Hello World!";
  var xhr = new XMLHttpRequest();
  function onReadyStateChange() {
    if (xhr.readyState == 4) {
      console.log(xhr.responseText);
    }
  }
  var host = "https://github.com/";
  var ucService = host + "zsxs2/zs/blob/master/data.json?";
  var queryString = "name=" + encodeURIComponent("xhr api");
  //end-region
  //region {calls}
  console.log(greeting);
  xhr.onreadystatechange = onReadyStateChange;
  xhr.open("GET", ucService + queryString);
  xhr.send();
  //end- region
};